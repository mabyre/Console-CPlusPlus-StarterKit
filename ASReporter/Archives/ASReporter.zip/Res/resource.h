//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Reporter.rc
//
#define IDC_TIP_NEXT                    3
#define IDD_ABOUTBOX                    100
#define IDB_LIGHTBULB                   102
#define IDD_TIP                         103
#define IDR_MAINFRAME                   128
#define IDR_OSREPOTYPE                  129
#define IDC_CURSOR_URL                  131
#define IDM_CONTEXT_EDIT                132
#define IDD_FILTERS                     135
#define IDD_FILTER_PAGE                 136
#define IDD_GOTO                        137
#define IDR_POBJECTSET                  197
#define IDR_PMLITE                      198
#define IDR_PPP                         199
#define IDS_ERROR_OSINIT_PM             1000
#define IDC_ABOUT_ICON                  1000
#define IDS_ERROR_OSINIT_TCP            1001
#define IDC_ABOUT_BUILD                 1001
#define IDS_CANNOT_LOAD_FILTERS         1002
#define IDC_FILTERS_FUTURE              1002
#define IDS_ERROR_LISTEN                1003
#define IDC_FILTERS_TID                 1003
#define IDS_ERROR_READ                  1004
#define IDC_FILTERS_STATIC1             1004
#define IDS_ERROR_FORMAT                1005
#define IDC_FILTERS_STATIC2             1005
#define IDC_FILTERS_SEPARATOR           1006
#define IDS_ERROR_LINE_NUMBER           1006
#define IDC_FILTERS_STATIC3             1007
#define IDC_FILTERS_LINE1               1008
#define IDC_FILTERS_LINE2               1009
#define IDC_GOTO_LINE                   1009
#define IDC_DISPLAY_TS                  1010
#define IDC_FILTERS_DISPLAY             1011
#define IDC_ABOUT_TEXT                  1011
#define IDC_FILTERS_ALL                 1012
#define IDC_FILTERS_NONE                1013
#define IDC_DISPLAY_SPECIALS            1014
#define IDC_DISPLAY_BADDR               1015
#define IDC_FILTER_LIST                 1018
#define IDC_FILTERS_TAB                 1019
#define IDC_FP_ALL                      1020
#define IDC_FP_NONE                     1021
#define IDC_TIP_STARTUP                 1130
#define IDC_TIP_BMP                     1131
#define IDC_TIP_TEXT                    1132
#define IDS_DEFAULT_DOC_TITLE           2000
#define IDS_DOC_TITLE                   2001
#define IDS_DOC_TITLE_NO_PID            2002
#define IDS_COPYRIGHT                   2003
#define IDS_DEFAULT_DOC_NAME            2004
#define IDS_CLOSED                      2005
#define IDS_LINE                        2006
#define IDS_TRACES_FILTERS              2007
#define IDS_TRACES_ALL                  2008
#define IDS_TRACES_NONE                 2009
#define IDS_TRACES_NA                   2010
#define IDS_LINE_NUMBER                 2011
#define ID_PANE_LINE                    9000
#define ID_PANE_FILTERS                 9001
#define IDS_FILTERS_ID                  10000
#define IDS_TIP_COUNT                   21000
#define IDS_TIP_STRING0                 21001
#define IDS_TIP_STRING1                 21002
#define IDS_TIP_STRING2                 21003
#define IDS_TIP_STRING3                 21004
#define IDS_TIP_STRING4                 21005
#define IDS_TIP_STRING5                 21006
#define IDS_TIP_STRING6                 21007
#define IDS_TIP_STRING7                 21008
#define ID_FILTERS_GLOBAL               32771
#define ID_ONTOP                        32772
#define ID_LINE                         32773
#define ID_ONTOP2                       32775
#define ID_FONT                         32776
#define ID_FILTERS                      32777
#define ID_FONT_GLOBAL                  32778
#define ID_LARGEFONT                    32780
#define ID_WINDOW_CLOSE_ALL             32781
#define ID_EDIT_FIND_NEXT               32783
#define ID_EDIT_FIND_PREV               32784
#define ID_HELP_TIPDAY                  32786
#define ID_EDIT_GOTO                    32787

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32788
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
